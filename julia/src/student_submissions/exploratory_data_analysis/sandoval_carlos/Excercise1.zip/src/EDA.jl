### A Pluto.jl notebook ###
# v0.20.3

using Markdown
using InteractiveUtils

# ╔═╡ e621ae3b-fe18-4828-8ed1-18bb09320921
begin
	# Adding Packages
	import Pkg

	Pkg.add("CSV")
	Pkg.add("DataFrames")
	Pkg.add("Statistics")
	Pkg.add("Plots")
	
	using CSV
	using DataFrames
	using Statistics
	using Plots
end

# ╔═╡ b179dac0-ad40-11ef-3bbf-21c3f8bc33a6
md" 
# Exploratory Data Analysis
Author: *Carlos Adrian Sandoval Cuenca (csandovalcuenca@gmail.com)*

## Instructions

1.  Get the CalCofi data set from <https://www.kaggle.com/datasets/sohier/calcofi>
2.  Work with the bottle.csv data.
3.  Use Julia to clean it (see below)
4.  Use Julia to do the list of EDA tasks listed below
5.  Produce a report showing your code and your results
6.  Submit your project following the submission guidelines
"

# ╔═╡ ea22f8bc-3eb6-4085-90f3-e10745e04220
begin
	# Loading Data
	folder = "D:/Carlos/Diplomado IA/Practicas/Exercise Set/DataSets/"
	file = "bottle.csv"
	path = folder * file
	Data = CSV.File(path) |> DataFrame
end

# ╔═╡ 9bd095b2-aaf1-4b42-9e4f-af1441e5dbdc
md"
## EDA Tasks
"

# ╔═╡ 940f288e-57c7-402f-a2b4-37f6122c5fd8
md" dataShape: to get shape of the data"

# ╔═╡ 0620b929-c8ee-4f97-915f-ab7da583b093
begin
	dataShape = function(Data::DataFrame) 
		return Dict("rows"=>nrow(Data),"columns"=>ncol(Data))
	end
	dataShape(Data)
end

# ╔═╡ 3797f611-3aca-47fd-a35f-9a93dec0948f
md"dataType: gives data type of each column in the dataset"

# ╔═╡ 698f1890-b62f-4a56-854b-9a5f7cb5a5c5
begin
	dataType = function(Data::DataFrame) 
		# Dictionary with percentage of missing values
		aux = Dict(col_name => eltype(Data[!, col_name]) for col_name in names(Data))
		# Data Frame with column names and column type
		return DataFrame(columns = collect(keys(aux)), types = collect(values(aux)))
	end
	dataType(Data)
end

# ╔═╡ 083633b3-1b75-44c4-9c81-708e313d7691
md"count_missing(col) : counts number of missing data in a given col (Column)"

# ╔═╡ 4de22b75-3d98-4fac-ba1e-2a267f2155e4
begin
	count_missing = function(Data::DataFrame,col::String) 
		return sum(ismissing.(Data[!,col]))
	end
	count_missing(Data,"T_degC")
end

# ╔═╡ 60f56edd-91d7-4377-8734-1f0ef7d35990
md"dataMissingPercentage(): finds missing percentage of each column"

# ╔═╡ 588964e1-10a3-44c8-90cf-90d750067998
begin
	dataMissingPercentage = function(Data::DataFrame)
		# Dictionary with percentage of missing values
		aux = Dict(col_name => count_missing(Data,col_name) / length(Data[!,col_name]) for col_name in names(Data))
		# Data Frame with column names and percentage of missing values
		return DataFrame(columns = collect(keys(aux)), missing_pctg = collect(values(aux)))
	end
	dataMissingPercentage(Data)
end

# ╔═╡ 6f051a21-a370-4a1b-97ea-a7ed15a79fa8
md"deleteColumns(threshold) : delete all the columns which have missing percent less than given threshold"

# ╔═╡ f402553d-a948-4704-8a38-a3d13615fb7d
begin
	deleteColumns = function(Data::DataFrame,threshold::Float64)
		# Data Frame with column names and percentage of missing values
		Aux = dataMissingPercentage(Data)
		# Filtering columns having a missing percentage lower than threshold
		Aux = subset(Aux, :missing_pctg => ByRow(<(threshold)); skipmissing=true)
		return select(Data,collect(Aux.columns))
	end
	deleteColumns(Data,0.10)
end

# ╔═╡ bfc36104-631c-4d4b-a7d6-0739fcbc3175
md"calculateCorrelation() : creates correlation matrix between columns"

# ╔═╡ 85216851-f551-4477-8a3d-8a78ddece78b
begin
	calculateCorrelation = function(Data::DataFrame,remove_columns::Bool,threshold::Float64)
		# Select numeric columns
		numeric_columns = [name for name in names(Data) if eltype(Data[!, name]) <: Union{Missing, Number}]
		Data_Numeric = Data[!, numeric_columns]
		# Remove columns having a missing percentage greater than threshold
		if(remove_columns == true)
			Data_Numeric = deleteColumns(Data_Numeric,threshold)  
		end
		# Remove rows having missing values and compute correlation
		return DataFrame(cor(Matrix(dropmissing(Data_Numeric))),names(Data_Numeric))
	end
	calculateCorrelation(Data,true,0.10)
end

# ╔═╡ d5bffb7d-aa28-44b4-9f3f-63498cc585a1
md"displayCorrelation() : dislpay correlation using heatmap"

# ╔═╡ 379fa184-5488-4a46-a504-cc4d71beb25c
begin
	displayCorrelation = function(Data::DataFrame,remove_columns::Bool,threshold::Float64)
		Plots.heatmap(Matrix(calculateCorrelation(Data,remove_columns,threshold)))
	end
	displayCorrelation(Data,true,0.10)
end	

# ╔═╡ 40bbb6e3-1b4f-4bf6-b4fc-e351f3529db5
md"removeOutliersIQR() : using interquartile range delete all the outliers from the numerical columns
"

# ╔═╡ d792f602-a262-40c9-a0e3-a47933b28ddc
begin
	removeOutliersIQR = function(Data::DataFrame,remove_columns::Bool,threshold::Float64)
		# Select numeric columns
		numeric_columns = [name for name in names(Data) if eltype(Data[!, name]) <: Union{Missing, Number}]
		Data_Numeric = Data[!, numeric_columns]
		# Remove columns having a missing percentage greater than threshold
		if(remove_columns == true)
			Data_Numeric = deleteColumns(Data_Numeric,threshold)  
		end
			  
		function classify_outliers(values::Vector)
		    # Convert tuple to array for numerical operations
		    data = collect(values)
			# Remove missing values for calculations
		    clean_data = skipmissing(data)
			# Calculate the 25th and 75th percentiles
		    q25, q75 = quantile(clean_data, [0.25, 0.75])
			# Classify values
		    outliers = map(x -> ismissing(x) ? false : x < q25 || x > q75, data)
			return outliers
		end

		# Apply classify_outliers() to each column of data frame
		Outlier_Data = DataFrame()
	    for col in names(Data_Numeric)
	        Outlier_Data[!, col] = classify_outliers(collect(Data_Numeric[!, col]))
	    end
	    
		# Identify rows containing an outlier in any column
		outlier_obs = Vector{Bool}(undef, nrow(Outlier_Data))
		for i in 1:nrow(Outlier_Data)
	        outlier_obs[i, :] .= maximum(collect(Outlier_Data[i, :]))
	    end

		# Filtering rows with no outliers in any column
		Outliers_Obs = DataFrame(:obs => 1:length(outlier_obs), :flag => outlier_obs) 
		Outliers_Obs = filter(:flag => ==(false), Outliers_Obs)
		
		return Data_Numeric[Outliers_Obs.obs,:]
	end
	removeOutliersIQR(Data,true,0.10)
end

# ╔═╡ ee7a3db9-7f44-4af8-9b95-3a1e37df820c
md"deleteRow(column): for a given column delete all the null data points"

# ╔═╡ b2c4ceab-a2e5-4f2d-8e83-e126ff1a4c62
begin
	deleteRow = function(Data::DataFrame,column::String)
		return dropmissing(Data, column)
	end
	deleteRow(Data,"NH3q")
end

# ╔═╡ 9f96959a-4699-4aa0-a01e-7bddead91788
md"filterColumnsByCorrelation(target,threshold, relation) : delete all the columns on the basis of given threshold for a target column and relation"

# ╔═╡ c6f3ed7d-520a-42ca-acbf-f8a8bb515de5
begin
	filterColumnsByCorrelation = function(Data::DataFrame,target_col::String, corr_threshold::Float64,remove_columns::Bool,threshold::Float64)
		Corr = calculateCorrelation(Data,true,threshold)
		Corr_Data = DataFrame("column" => names(Corr), "correlation" => Corr[!,target_col])
		Corr_Data = filter(:correlation => x -> abs(x)>=corr_threshold, Corr_Data)

		return select(Data,Corr_Data.column)
	end
	filterColumnsByCorrelation(Data,"T_degC",0.50,true,0.10)
end

# ╔═╡ edcedd32-3cc7-4a0a-8a72-c5569c5fdc51
md"describe() : it is used to describe data by giving following for each column/"

# ╔═╡ 2322f4cb-0a05-4cc2-b03e-7efd78c41f96
begin
	describe(Data)
end

# ╔═╡ Cell order:
# ╟─b179dac0-ad40-11ef-3bbf-21c3f8bc33a6
# ╠═e621ae3b-fe18-4828-8ed1-18bb09320921
# ╠═ea22f8bc-3eb6-4085-90f3-e10745e04220
# ╟─9bd095b2-aaf1-4b42-9e4f-af1441e5dbdc
# ╟─940f288e-57c7-402f-a2b4-37f6122c5fd8
# ╠═0620b929-c8ee-4f97-915f-ab7da583b093
# ╟─3797f611-3aca-47fd-a35f-9a93dec0948f
# ╠═698f1890-b62f-4a56-854b-9a5f7cb5a5c5
# ╟─083633b3-1b75-44c4-9c81-708e313d7691
# ╠═4de22b75-3d98-4fac-ba1e-2a267f2155e4
# ╟─60f56edd-91d7-4377-8734-1f0ef7d35990
# ╠═588964e1-10a3-44c8-90cf-90d750067998
# ╟─6f051a21-a370-4a1b-97ea-a7ed15a79fa8
# ╠═f402553d-a948-4704-8a38-a3d13615fb7d
# ╟─bfc36104-631c-4d4b-a7d6-0739fcbc3175
# ╠═85216851-f551-4477-8a3d-8a78ddece78b
# ╟─d5bffb7d-aa28-44b4-9f3f-63498cc585a1
# ╠═379fa184-5488-4a46-a504-cc4d71beb25c
# ╟─40bbb6e3-1b4f-4bf6-b4fc-e351f3529db5
# ╠═d792f602-a262-40c9-a0e3-a47933b28ddc
# ╟─ee7a3db9-7f44-4af8-9b95-3a1e37df820c
# ╠═b2c4ceab-a2e5-4f2d-8e83-e126ff1a4c62
# ╟─9f96959a-4699-4aa0-a01e-7bddead91788
# ╠═c6f3ed7d-520a-42ca-acbf-f8a8bb515de5
# ╟─edcedd32-3cc7-4a0a-8a72-c5569c5fdc51
# ╠═2322f4cb-0a05-4cc2-b03e-7efd78c41f96
