### A Pluto.jl notebook ###
# v0.20.3

using Markdown
using InteractiveUtils

# ╔═╡ 97e09107-d76a-4e04-ad7a-12e6719405be
begin
	# Adding Packages
	import Pkg

	Pkg.add("CSV")
	Pkg.add("DataFrames")
	Pkg.add("Statistics")
	Pkg.add("StatsModels")
	Pkg.add("Plots")
	Pkg.add("GLM")
	Pkg.add("MLJ")
	
	using CSV
	using DataFrames
	using Statistics
	using StatsModels
	using Plots
	using GLM
	using MLJ
end

# ╔═╡ 0b723b00-bc17-11ef-3687-47d5af66e197
md" 
# Linear Regression
Author: *Carlos Adrian Sandoval Cuenca (csandovalcuenca@gmail.com)*

## Instructions

Use the bottle.csv data from the CalCofi dataset to determine the most important factors of T_degC 

1. Use the EDA you already have done in Julia
2. Use Julia to do linear regressions combining different sets of independent variables until you find the combination that gives you better predictions
3. Submit your project following the submissions guidelines 

"

# ╔═╡ bc9c2db6-fa6d-4efd-9c6b-f55523081633
begin
	# Loading Data
	folder = "D:/Carlos/Diplomado IA/Practicas/Exercise Set/DataSets/"
	file = "bottle.csv"
	path = folder * file
	Data = CSV.File(path) |> DataFrame
end

# ╔═╡ 9eebd860-21a2-4a79-8a9b-056c315a2c79
md"Functions for EDA"

# ╔═╡ 53a374a2-c301-4638-b32e-4cdb1551198a
begin
	dataType = function(Data::DataFrame) 
		# Dictionary with percentage of missing values
		aux = Dict(col_name => eltype(Data[!, col_name]) for col_name in names(Data))
		# Data Frame with column names and column type
		return DataFrame(columns = collect(keys(aux)), types = collect(values(aux)))
	end

	count_missing = function(Data::DataFrame,col::String) 
		return sum(ismissing.(Data[!,col]))
	end

	dataMissingPercentage = function(Data::DataFrame)
		# Dictionary with percentage of missing values
		aux = Dict(col_name => count_missing(Data,col_name) / length(Data[!,col_name]) for col_name in names(Data))
		# Data Frame with column names and percentage of missing values
		return DataFrame(columns = collect(keys(aux)), missing_pctg = collect(values(aux)))
	end

	deleteColumns = function(Data::DataFrame,threshold::Float64)
		# Data Frame with column names and percentage of missing values
		Aux = dataMissingPercentage(Data)
		# Filtering columns having a missing percentage lower than threshold
		Aux = subset(Aux, :missing_pctg => ByRow(<(threshold)); skipmissing=true)
		return select(Data,collect(Aux.columns))
	end

	calculateCorrelation = function(Data::DataFrame,remove_columns::Bool,threshold::Float64)
		# Select numeric columns
		numeric_columns = [name for name in names(Data) if eltype(Data[!, name]) <: Union{Missing, Number}]
		Data_Numeric = Data[!, numeric_columns]
		# Remove columns having a missing percentage greater than threshold
		if(remove_columns == true)
			Data_Numeric = deleteColumns(Data_Numeric,threshold)  
		end
		# Remove rows having missing values and compute correlation
		return DataFrame(cor(Matrix(dropmissing(Data_Numeric))),names(Data_Numeric))
	end

	displayCorrelation = function(Data::DataFrame,remove_columns::Bool,threshold::Float64)
		Plots.heatmap(Matrix(calculateCorrelation(Data,remove_columns,threshold)))
	end
	
	removeOutliersIQR = function(Data::DataFrame,remove_columns::Bool,threshold::Float64)
		# Select numeric columns
		numeric_columns = [name for name in names(Data) if eltype(Data[!, name]) <: Union{Missing, Number}]
		Data_Numeric = Data[!, numeric_columns]
		# Remove columns having a missing percentage greater than threshold
		if(remove_columns == true)
			Data_Numeric = deleteColumns(Data_Numeric,threshold)  
		end
			  
		function classify_outliers(values::Vector)
		    # Convert tuple to array for numerical operations
		    data = collect(values)
			# Remove missing values for calculations
		    clean_data = skipmissing(data)
			# Calculate the 25th and 75th percentiles
		    q25, q75 = quantile(clean_data, [0.25, 0.75])
			# Classify values
		    outliers = map(x -> ismissing(x) ? false : x < q25 || x > q75, data)
			return outliers
		end

		# Apply classify_outliers() to each column of data frame
		Outlier_Data = DataFrame()
	    for col in names(Data_Numeric)
	        Outlier_Data[!, col] = classify_outliers(collect(Data_Numeric[!, col]))
	    end
	    
		# Identify rows containing an outlier in any column
		outlier_obs = Vector{Bool}(undef, nrow(Outlier_Data))
		for i in 1:nrow(Outlier_Data)
	        outlier_obs[i, :] .= maximum(collect(Outlier_Data[i, :]))
	    end

		# Filtering rows with no outliers in any column
		Outliers_Obs = DataFrame(:obs => 1:length(outlier_obs), :flag => outlier_obs) 
		Outliers_Obs = filter(:flag => ==(false), Outliers_Obs)
		
		return Data_Numeric[Outliers_Obs.obs,:]
	end

	filterColumnsByCorrelation = function(Data::DataFrame,target_col::String, corr_threshold::Float64,remove_columns::Bool,threshold::Float64)
		Corr = calculateCorrelation(Data,true,threshold)
		Corr_Data = DataFrame("column" => names(Corr), "correlation" => Corr[!,target_col])
		Corr_Data = filter(:correlation => x -> abs(x)>=corr_threshold, Corr_Data)

		return select(Data,Corr_Data.column)
	end

end

# ╔═╡ c1b18719-2aa9-44ed-b583-8a21af9b13a9
md"## EDA"

# ╔═╡ 48e5b0fb-0828-4b75-9bd7-09411ba9f827
md"Deleting columns with percentage of missing values greater than 10% and selecting numeric columns having correlation with **T_degC** greater than 50%"

# ╔═╡ 76e0911d-f1cb-43ec-b34f-f7bf0bdae989
begin
	Data_Correlated = filterColumnsByCorrelation(Data,"T_degC",0.40,true,0.10)
	Data_Correlated = dropmissing(Data_Correlated)
	describe(Data_Correlated)
end

# ╔═╡ 0dd18c68-6940-4623-8295-132027258db8
md"From the above table, we can see that the variables **STheta** and **R_Sigma** have at least one upper outlier sinces their max value is far away from the mean and median.

Thus we proceed to remove outliers"

# ╔═╡ ca7dfa43-d650-4d5a-be77-99347a5eb942
begin
	Data_Clean = removeOutliersIQR(Data_Correlated,true,0.10)
	describe(Data_Clean)
end

# ╔═╡ fd6c9b75-9135-47e0-a97e-39362820803f
Corr = calculateCorrelation(Data_Clean,true,0.10)

# ╔═╡ 7591bb5b-9e43-4a33-827f-9ef4673af727
begin 
	Corr_Columns = DataFrame("column" => names(Corr), "correlation" => Corr[!,"T_degC"])
	filter(:column => !=("T_degC"), Corr_Columns)
end

# ╔═╡ 66a4ea54-993a-4996-a4bf-81a94d4d116f
md"
From the description of the columns and correlation matrix, we see that: 
- **Depthm** is identical with **R_Depth**, **R_DYNHT** and **R_PRES**
- **R_TEMP** is identical to the regressed variable **T_degC**
- **STheta** is strongly correlated to **R_SIGMA** and to **R_SVA**
- **R_SALINITY** is strongly correlated to **Salnty**
- **R_POTEMP** is identical to **R_TEMP**
- **Depthm**, **R_PRES**, **R_Depth** and **R_DYNHT** are strongly correlated and are not linearly correlated to the regressed variable **T_degC**

In order to avoid any colinearity issues, we need to select uncorrelated variables as regressors. Thus, we drop **Depthm**, **R_DYNHT**, **R_PRES**, **R_TEMP**, **R_SIGMA**, **R_SVA**, **Salnty** ,**R_POTEMP** 
"

# ╔═╡ ab5bbc7c-cbd1-43e5-acc1-746ab9ea4b5d
begin
	Data_Final = select(Data_Clean, Not([:Depthm, :R_DYNHT, :R_PRES, :R_TEMP, :R_SIGMA, :R_SVA, :Salnty, :R_POTEMP]))
	describe(Data_Final)
end

# ╔═╡ 8c9554fe-8013-4752-a894-c6bd80bf13a0
calculateCorrelation(Data_Final,false,0.0)

# ╔═╡ 2080d0f3-01fc-4081-bdf2-d0edb2d0f84e
md"Graphical visualization of remaining columns"

# ╔═╡ 01e31d6b-4947-488a-b009-427967486375
begin
	y_var = "T_degC"
	y = Data_Final[!,y_var]

	x_names = ["R_SALINITY", "STheta", "R_Depth"]
	X = [Data_Final[!,x_var] for x_var in x_names]
	plot(X, y, layout=(1, 3), legend=false, seriestype=:scatter)
end

# ╔═╡ 20b1d22b-22ee-4f21-b16a-907d37729b47
md"## Linear Regression"

# ╔═╡ c688a7ac-69f9-4523-a932-4b3fff3836cc
md"
We use all combinations of the regressor variables **R_SALINITY**, **STheta**, **R_Depth** to explain **T_degC**
- Model 1: **T_degC** ~ **R_SALINITY**
- Model 2: **T_degC** ~ **STheta**
- Model 3: **T_degC** ~ **R_Depth**
- Model 4: **T_degC** ~ **R_SALINITY** + **STheta**
- Model 5: **T_degC** ~ **R_SALINITY** + **R_Depth**
- Model 6: **T_degC** ~ **R_SALINITY** + **STheta** + **R_Depth**
"

# ╔═╡ 52bf3dc2-ffb4-4756-b645-df1b82b865be
# Model 1
m1 = lm(@formula(T_degC ~ R_SALINITY), Data_Final)

# ╔═╡ 87b62a42-d611-4050-8897-5c95f05288cb
# Model 2
m2 = lm(@formula(T_degC ~ STheta), Data_Final)

# ╔═╡ 92043ab3-1989-4c0b-8a4a-4e82c37d40d6
# Model 3
m3 = lm(@formula(T_degC ~ R_Depth), Data_Final)

# ╔═╡ 6cf50def-dd04-49a6-bb65-f401954b9843
# Model 4
m4 = lm(@formula(T_degC ~ R_SALINITY + STheta), Data_Final)

# ╔═╡ e44873d1-0cc6-4075-b83a-1aa7e17ee9bf
# Model 5
m5 = lm(@formula(T_degC ~ R_SALINITY + R_Depth), Data_Final)

# ╔═╡ cc145d94-ff19-4366-85aa-1897f0205dce
# Model 6
m6 = lm(@formula(T_degC ~ R_SALINITY + STheta + R_Depth), Data_Final)

# ╔═╡ c7466633-00ce-4f4e-a353-ae2bb71987a0
md"Comparison between models"

# ╔═╡ 5deed426-e18f-4e43-9a22-15e51e2ce74e
Results = DataFrame(
	"model" => "m".*string.(collect(1:6)),
	"r2" => [round(r2(m1); digits=4),
				round(r2(m2); digits=4),
				round(r2(m3); digits=4),
				round(r2(m4); digits=4),
				round(r2(m5); digits=4),
				round(r2(m6); digits=4)],
	"adj_r2" => [round(adjr2(m1); digits=4),
				round(adjr2(m2); digits=4),
				round(adjr2(m3); digits=4),
				round(adjr2(m4); digits=4),
				round(adjr2(m5); digits=4),
				round(adjr2(m6); digits=4)],
	"BIC" => [round(StatsModels.bic(m1); digits=4),
				round(StatsModels.bic(m2); digits=4),
				round(StatsModels.bic(m3); digits=4),
				round(StatsModels.bic(m4); digits=4),
				round(StatsModels.bic(m5); digits=4),
				round(StatsModels.bic(m6); digits=4)],
	"AIC" => [round(StatsModels.aic(m1); digits=4),
				round(StatsModels.aic(m2); digits=4),
				round(StatsModels.aic(m3); digits=4),
				round(StatsModels.aic(m4); digits=4),
				round(StatsModels.aic(m5); digits=4),
				round(StatsModels.aic(m6); digits=4)])

# ╔═╡ 7d726cba-bcac-4a0f-b90c-112bbcb8b0ce
md"From the previous results, we can see that the models with biggest R2 and adjusted R2 and lower AIC and BIC, are models 4 and 6. Model 4 have slighly better values than model 6 and using the principle of parsimony, we choose model 4 as the final one. That is, the best avriables for explaining **T_degC** are **R_SALINITY** and **STheta**"

# ╔═╡ Cell order:
# ╟─0b723b00-bc17-11ef-3687-47d5af66e197
# ╠═97e09107-d76a-4e04-ad7a-12e6719405be
# ╠═bc9c2db6-fa6d-4efd-9c6b-f55523081633
# ╟─9eebd860-21a2-4a79-8a9b-056c315a2c79
# ╟─53a374a2-c301-4638-b32e-4cdb1551198a
# ╟─c1b18719-2aa9-44ed-b583-8a21af9b13a9
# ╟─48e5b0fb-0828-4b75-9bd7-09411ba9f827
# ╠═76e0911d-f1cb-43ec-b34f-f7bf0bdae989
# ╟─0dd18c68-6940-4623-8295-132027258db8
# ╠═ca7dfa43-d650-4d5a-be77-99347a5eb942
# ╠═fd6c9b75-9135-47e0-a97e-39362820803f
# ╠═7591bb5b-9e43-4a33-827f-9ef4673af727
# ╟─66a4ea54-993a-4996-a4bf-81a94d4d116f
# ╠═ab5bbc7c-cbd1-43e5-acc1-746ab9ea4b5d
# ╠═8c9554fe-8013-4752-a894-c6bd80bf13a0
# ╟─2080d0f3-01fc-4081-bdf2-d0edb2d0f84e
# ╠═01e31d6b-4947-488a-b009-427967486375
# ╟─20b1d22b-22ee-4f21-b16a-907d37729b47
# ╟─c688a7ac-69f9-4523-a932-4b3fff3836cc
# ╠═52bf3dc2-ffb4-4756-b645-df1b82b865be
# ╠═87b62a42-d611-4050-8897-5c95f05288cb
# ╠═92043ab3-1989-4c0b-8a4a-4e82c37d40d6
# ╠═6cf50def-dd04-49a6-bb65-f401954b9843
# ╠═e44873d1-0cc6-4075-b83a-1aa7e17ee9bf
# ╠═cc145d94-ff19-4366-85aa-1897f0205dce
# ╟─c7466633-00ce-4f4e-a353-ae2bb71987a0
# ╠═5deed426-e18f-4e43-9a22-15e51e2ce74e
# ╟─7d726cba-bcac-4a0f-b90c-112bbcb8b0ce
