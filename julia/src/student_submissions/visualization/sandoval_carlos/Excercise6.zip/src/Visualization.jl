### A Pluto.jl notebook ###
# v0.20.3

using Markdown
using InteractiveUtils

# ╔═╡ b73ffb9c-2f20-4d57-9a5a-15352a0f9522
begin
	# Adding Packages
	import Pkg

	Pkg.add("Graphs")
	Pkg.add("GraphMakie")
	Pkg.add("CairoMakie")
	Pkg.add("Random")
	Pkg.add("Weave")
	
	using Graphs
	using GraphMakie
	using CairoMakie
	using Random
	using Weave
end

# ╔═╡ a7689080-ce2e-11ef-0a23-2da2affff58b
md"
# Visualization

## Instructions

Produce the plot shown below in Julia. You may use the Plots or the Makie Package.
1. Submit your project following the submission guidelines
2. Be sure that you include the code and the figure(s)
"

# ╔═╡ 7fa6142b-6721-4d53-ba7b-3fe2b17f5dd7
begin
	# Function for finding a node near the center (0.5, 0.5)
	function findCenter(points::Matrix{Float32})::Int64
		currentDistance = Inf
		currentCenter = 0
		for (i, p) in enumerate(eachcol(points))
			distance = (p[1] - 0.5)^2 + (p[2] - 0.5)^2
			if distance < currentDistance
				currentDistance = distance
				currentCenter = i
			end
		end
		currentCenter
	end

	# Function to create a random graph
	function drawRandomGeometricGraph(points::Matrix{Float32})
	graph, = euclidean_graph(points; cutoff=0.125)
	centerNode = findCenter(points)
	nodeColor = dijkstra_shortest_paths(graph, centerNode).dists
	nodeSize = fill(10, nv(graph))
	nodeSize[centerNode] = 20
	nodeLabels = 1:nv(graph)
	fontSize = fill(0, nv(graph))
	fontSize[centerNode] = 8
	
	fig, ax, p = graphplot(graph;
		node_size=nodeSize,
		node_color=nodeColor,
		ilabels_fontsize=fontSize,
		ilabels=nodeLabels,
		ilabels_color=:white,
		node_attr=( colormap=Reverse(:amp), colorrange=(1,maximum(nodeColor)) )
	)
	hidedecorations!(ax);
	hidespines!(ax)
	ax.aspect = DataAspect()
	fig
	end
end

# ╔═╡ b5d9acd9-7c66-4f7f-8b32-8b3fd9eb4b6b
begin
	points = rand(Xoshiro(4), Float32, (2, 200))
	drawRandomGeometricGraph(points)

end

# ╔═╡ Cell order:
# ╟─a7689080-ce2e-11ef-0a23-2da2affff58b
# ╠═b73ffb9c-2f20-4d57-9a5a-15352a0f9522
# ╠═7fa6142b-6721-4d53-ba7b-3fe2b17f5dd7
# ╠═b5d9acd9-7c66-4f7f-8b32-8b3fd9eb4b6b
